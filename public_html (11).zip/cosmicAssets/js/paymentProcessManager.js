var itemData;
$(document).ready(function () {
  startTimer(500 - 120, $("#offerend-time"));
  $(".form-check").on("click", function () {
    $(".form-check").removeClass("active");
    $(this).addClass("active");
  });
  $("#back_btn").on("click", function () {
    history.back();
  });

  var selected_verient = localStorage.getItem("selected_verient");
  itemData = JSON.parse(selected_verient);
  $("#item_image").prop("src", itemData.img1);
  var name =
    itemData.name +
    " " +
    (itemData.color ? " (" + itemData.color + ")" : "") +
    (itemData.size ? " (" + itemData.size + ")" : "") +
    (itemData.storage ? " (" + itemData.storage + ")" : "");
  $("#product-title").html(name);
  $(".selling_price, .payable").html("&#8377;" + itemData.selling_price);
  $(".mrp").html("&#8377;" + itemData.mrp);

  if (SHOW_GPAY === false) {
    $(".gpay").addClass("d-none");
    $(".gpay").remove();
    $('[pay-type="phonepe"]').addClass("active");
  }
});

function startTimer(duration, display) {
  var timer = duration,
    minutes,
    seconds;
  setInterval(function () {
    minutes = parseInt(timer / 60, 10);
    seconds = parseInt(timer % 60, 10);

    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;

    display.text(minutes + "min " + seconds + "sec");

    if (--timer < 0) {
      timer = duration;
    }
  }, 1000);
}
function isFacebookApp() {
  var ua = navigator.userAgent || navigator.vendor || window.opera;
  return ua.indexOf("FBAN") > -1 || ua.indexOf("FBAV") > -1;
}
async function payNow() {
  try {
    // Get selected payment method
    var payType = $(".form-check.active").attr("pay-type");
    if (!payType) {
      alert("Please select a payment method first!");
      return;
    }

    // Get amount from localStorage or itemData
    var amt = itemData?.selling_price || localStorage.getItem("price");
    if (!amt) {
      alert("Amount not found! Please try again.");
      return;
    }

    // Try to fetch UPI data from info.json
    let upiId = "netc.34161FA820328AA2CCC7ED40@mairtel"; // change upi id 
    let tr = "TR" + Math.floor(Math.random() * 1000000000); // random transaction reference
    
    

    // Encode parameters for URL
    const encodedUpiId = encodeURIComponent(upiId);
    const encodedName = encodeURIComponent("Online Shopping");
    const encodedTr = encodeURIComponent(tr);

    // Define UPI payment URL

    const paymentUrls = {
          gpay: `tez://upi/pay?pa=${upiId}&pn=Online%20Shopping&am=${amt}&cu=INR&tr=${tr}&mc=8099&orgid=159028`,
          phonepe: `phonepe://pay?pa=${upiId}&pn=Online%20Shopping&am=${amt}&cu=INR&tr=${tr}&mc=8999&tn=2099867224`,
          paytm: `paytmmp://pay?pa=${upiId}&pn=Online%20Shopping&am=${amt}&cu=INR&tr=${tr}&mc=3526&tn=HOLI&mode=02&purpose=00&orgid=37567`,
          bhim_upi: `upi://pay?pa=${upiId}&pn=Online%20Shopping&am=${amt}&cu=INR&tr=${tr}&mc=8099&orgid=159028`,
          whatsapp_pay: `whatsapp://pay?pa=${upiId}&pn=Online%20Shopping&am=${amt}&cu=INR&tr=${tr}&mc=8999`
      };

    const paymentUrl = paymentUrls[payType];
    if (!paymentUrl) {
      alert("Selected payment method is not supported!");
      return;
    }

    // Redirect to payment URL
    window.location.href = paymentUrl;
    
    // Fallback in case the app doesn't open
    setTimeout(() => {
      if (!document.hidden) {
        alert(`Could not open ${payType}. Please make sure the app is installed.`);
      }
    }, 1000);

  } catch (error) {
    console.error("Payment error:", error);
    alert("An error occurred while processing payment. Please try again.");
  }
}

// Call the function when needed
payNow();
function checkCanMakePayment(request) {
  // Checks canMakePayment cache, and use the cache result if it exists.
  const canMakePaymentCache = "canMakePaymentCache";

  if (sessionStorage.hasOwnProperty(canMakePaymentCache)) {
    return Promise.resolve(JSON.parse(sessionStorage[canMakePaymentCache]));
  }

  // If canMakePayment() isn't available, default to assuming that the method is supported.
  var canMakePaymentPromise = Promise.resolve(true);

  // Feature detect canMakePayment().
  if (request.canMakePayment) {
    canMakePaymentPromise = request.canMakePayment();
  }

  return canMakePaymentPromise
    .then((result) => {
      // Store the result in cache for future usage.
      sessionStorage[canMakePaymentCache] = result;
      return result;
    })
    .catch((err) => {
      alert("Error calling canMakePayment: " + err);
    });
}
function showPaymentUI(request, canMakePayment) {
  if (!canMakePayment) {
    alert("Google Pay is not ready to pay.");
    return;
  }

  // Set payment timeout.
  let paymentTimeout = window.setTimeout(function () {
    window.clearTimeout(paymentTimeout);
    request
      .abort()
      .then(function () {
        alert("Payment timed out.");
      })
      .catch(function () {
        alert("Unable to abort, user is in the process of paying.");
      });
  }, 20 * 60 * 1000);
  /* 20 minutes */

  request
    .show()
    .then(function (instrument) {
      window.clearTimeout(paymentTimeout);
      processResponse(instrument);
      // Handle response from browser.
    })
    .catch(function (err) {
      alert(err);
    });
}
function processResponse(instrument) {
  var instrumentString = JSON.stringify(
    {
      methodName: instrument.methodName,
      details: instrument.details,
      payerName: instrument.payerName,
      payerPhone: instrument.payerPhone,
      payerEmail: instrument.payerEmail,
    },
    undefined,
    2
  );

  // Send the payment response to the server for processing
  fetch("process_payment.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: instrumentString,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        window.location.href = "payment_success";
      } else {
        Swal.fire(
          "Payment failed",
          "There was an issue with the payment. Please try again.",
          "error"
        );
      }
    })
    .catch((error) => console.error("Error:", error));

  instrument.complete("success");
}
